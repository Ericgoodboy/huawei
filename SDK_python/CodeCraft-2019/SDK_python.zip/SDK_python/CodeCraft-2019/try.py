# !/usr/bin/python3
# -*- coding : UTF-8 -*-
# @author   : 关宅宅
# @time     : 2019-4-1 15:03
# @file     : try.py
# @Software : PyCharm Community Edition

def getPriCar(path):
    count = 0
    with open(path, "r") as f:
        lines = f.readlines()
        for line in lines:
            tempCount = line.split(',')
            if '1' in tempCount[5]:
                count += 1
    return count

if __name__ == '__main__':
    path = '2-map-training-2/car.txt'
    print(getPriCar(path))