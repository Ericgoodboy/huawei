

class Cross(object):
    TYPE="Cross"
    def __init__(self,id,nRoadId,eRoadId,sRoadId,wRoadId):
        self.id=id
        self.nRoadId=nRoadId
        self.eRoadId=eRoadId
        self.wRoadId=wRoadId
        self.sRoadId=sRoadId
        self.allRoad =[nRoadId,eRoadId,sRoadId,wRoadId]#n=0,e=1,s=
        self.flag=0
        self.pos=()
        self.carReady=[[],[],[]]
    def runIncross(self,processCarPool,roadPool,crossPool):
        changeRoad=0
        changeRoad+=self.goInPort(processCarPool,roadPool,crossPool)
        l1=self.goSright(processCarPool,roadPool,crossPool)
        if l1>0:
            return changeRoad+l1
        l2=self.goLeft(processCarPool,roadPool,crossPool)
        if l2>0:
            return l2+changeRoad
        changeRoad+=self.goRight(processCarPool,roadPool,crossPool)
        return changeRoad
    def moveAllRoad(self, roadId, index):
        index = index % 4
        indexnow = self.allRoad.index(roadId)
        neg = (index - indexnow) % 4
        for i in range(neg):
            self.allRoad.insert(0, self.allRoad.pop())
        pass
    def goSright(self,processCarPool,roadPool,crossPool):
        changeRoad=0
        for road in self.allRoad:
            if road == -1:
                continue
            if roadPool[road].isDuplex:
                # get a trouble!!!
                place = roadPool[road].placesA if roadPool[road].toCrossId == self.id else roadPool[road].placesB
            else:
                if roadPool[road].toCrossId!=self:
                    continue
                else:
                    place = roadPool[road].placesA
            xlen=len(place[0])
            #ylen=len(place)
            print(place)
            flag=[True for i in place]
            for i in range(len(place[0])):
                for j in range(len(place)):
                    if flag[j]!=True:
                        continue
                    if place[j][xlen-i-1] !=0:
                        car=processCarPool[place[j][xlen-i-1]]
                        if car.togoNext ==2:
                            indexNow=self.allRoad.index(road)
                            indexNext=indexNow-2
                            if self.allRoad[indexNext]==-1:
                                print("----------")
                                print(self.id)
                                print(self)
                                print(self.allRoad)
                                print(car.id)
                            nextRoad=roadPool[self.allRoad[indexNext]]
                            placeNext=nextRoad.placesA if nextRoad.fromCrossId ==self.id else nextRoad.placesB
                            x,y=self.handlePlace(placeNext)
                            v=min(car.speed,nextRoad.speed)
                            if x == -2:
                                car.isReadyToGo=False
                            elif x==-1:
                                self.handleCarGo(place,(j,xlen-i-1),placeNext,(0,v-1),car,v,roadPool,crossPool,nextRoad.id)
                                changeRoad+=1
                            else:
                                self.handleCarGo(place,(j,xlen-i-1),placeNext,(x,min(y,v-car.lest-1)),car,v,roadPool,crossPool,nextRoad.id)
                                changeRoad+=1
                        else:
                            flag[j]=False
        return changeRoad
    def handleCarGo(self,fromRoad,fromIndex,toRoad,toIndex,car,v,roadPool,crossPool,roadId):
        fx,fy=fromIndex
        fromRoad[fx][fy]=0
        tx,ty=toIndex
        toRoad[tx][ty]=car.id
        car.isReadyToGo = False
        if ty+v-1<len(toRoad[0]):
             car.canGoOnRoad=True
        else:
            car.canGoOnRoad=False
            car.lest=len(toRoad[0])-ty

            indexRoad=car.path.index(roadId)
            if indexRoad==len(car.path)-1:
                car.togoNext=0
            else:
                #待检查
                nextRoad = car.path[indexRoad + 1]
                temp = [roadPool[roadId].fromCrossId, roadPool[roadId].toCrossId]
                cross = roadPool[nextRoad].fromCrossId if roadPool[nextRoad].fromCrossId in temp else roadPool[
                    nextRoad].toCrossId
                f = crossPool[cross].allRoad.index(roadPool[roadId].id)
                t = crossPool[cross].allRoad.index(nextRoad)
                print("cross"+"carId:",car.id,"f:",f,"t",t)
                direction = (f - t) % 4
                car.togoNext = direction
    def handlePlace(self,place):
        for i in range(len(place)):
            if place[i][0]!=0:
                continue
            for j in place[i]:
                if j !=0:
                    return (i,j-1)
        if place[len(place)-1][0] !=0:
            return (-2,0)
        return (-1,-1)
    def goLeft(self,processCarPool,roadPool,crossPool):
        changeRoad = 0
        for road in self.allRoad:
            if road == -1:
                continue
            if roadPool[road].isDuplex:
                place = roadPool[road].placesA if roadPool[road].toCrossId == self.id else roadPool[road].placesB
            else:
                if roadPool[road].toCrossId!=self:
                    continue
                else:
                    place = roadPool[road].placesA
            xlen = len(place[0])
            # ylen=len(place)
            flag = [True for i in place]
            for i in range(len(place[0])):
                for j in range(len(place)):
                    if flag[j] != True:
                        continue
                    if place[j][xlen - i - 1] != 0:
                        car = processCarPool[place[j][xlen - i - 1]]
                        if car.togoNext == 3:
                            indexNow = self.allRoad.index(road)
                            indexNext = indexNow - 3
                            nextRoad = roadPool[self.allRoad[indexNext]]
                            placeNext = nextRoad.placesA if nextRoad.fromCrossId == self.id else nextRoad.placesB
                            x, y = self.handlePlace(placeNext)
                            v = min(car.speed, nextRoad.speed)
                            if x == -2:
                                car.isReadyToGo = False
                            elif x == -1:
                                self.handleCarGo(place, (j, xlen - i - 1), placeNext, (x, y), car, v, roadPool,
                                                 crossPool, nextRoad.id)
                                changeRoad += 1
                            else:
                                self.handleCarGo(place, (j, xlen - i - 1), placeNext, (x, min(y, v - car.lest - 1)),
                                                 car, v, roadPool, crossPool, nextRoad.id)
                                changeRoad += 1
                        else:
                            flag[j] = False
        return changeRoad
    def goRight(self,processCarPool,roadPool,crossPool):
        changeRoad=0
        for road in self.allRoad:
            if road == -1:
                continue
            if roadPool[road].isDuplex:
                place = roadPool[road].placesA if roadPool[road].toCrossId == self.id else roadPool[road].placesB
            else:
                if roadPool[road].toCrossId!=self:
                    continue
                else:
                    place = roadPool[road].placesA
            xlen = len(place[0])
            # ylen=len(place)
            flag = [True for i in place]
            for i in range(len(place[0])):
                for j in range(len(place)):
                    if flag[j] != True:
                        continue
                    if place[j][xlen - i - 1] != 0:
                        car = processCarPool[place[j][xlen - i - 1]]
                        if car.togoNext == 1:
                            indexNow = self.allRoad.index(road)
                            indexNext = indexNow - 1
                            nextRoad = roadPool[self.allRoad[indexNext]]
                            placeNext = nextRoad.placesA if nextRoad.fromCrossId == self.id else nextRoad.placesB
                            x, y = self.handlePlace(placeNext)
                            v = min(car.speed, nextRoad.speed)
                            if x == -2:
                                car.isReadyToGo = False
                            elif x == -1:
                                self.handleCarGo(place, (j, xlen - i - 1), placeNext, (x, y), car, v, roadPool,
                                                 crossPool, nextRoad.id)
                                changeRoad += 1
                            else:
                                self.handleCarGo(place, (j, xlen - i - 1), placeNext, (x, min(y, v - car.lest - 1)),
                                                 car, v, roadPool, crossPool, nextRoad.id)
                                changeRoad += 1
                        else:
                            flag[j] = False
        return changeRoad
    def goInPort(self,processCarPool,roadPool,crossPool):
        changeRoad =0
        for road in self.allRoad:
            if road == -1:
                continue
            if roadPool[road].isDuplex:
                place = roadPool[road].placesA if roadPool[road].toCrossId == self.id else roadPool[road].placesB
            else:
                if roadPool[road].toCrossId!=self:
                    continue
                else:
                    place = roadPool[road].placesA
            xlen = len(place[0])
            # ylen=len(place)
            flag = [True for i in place]
            for i in range(len(place[0])):
                for j in range(len(place)):
                    if flag[j] != True:
                        continue
                    if place[j][xlen - i - 1] != 0:
                        car = processCarPool[place[j][xlen - i - 1]]
                        if car.togoNext == 0:
                            car.isReadyToGo=False
                            car.endState=True
                            changeRoad += 1
                            place[j][xlen - i - 1]=0
                            processCarPool.pop(car.id)
                        else:
                            flag[j] = False
        return changeRoad

    def __str__(self):
        ref="\nn:"+str(self.nRoadId)
        ref+="\ne:"+str(self.eRoadId)
        ref+="\nw:"+str(self.wRoadId)
        ref+="\ns:"+str(self.sRoadId)
        return ref





