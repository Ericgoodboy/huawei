class PresetCar(object):
    def __init__(self,id,bestStartTime, answer):
        self.id=id
        self.bestStartTime=bestStartTime
        self.answer=answer

    def __str__(self):
        return str(self.id) + ":" + str(self.bestStartTime) + str(self.answer)