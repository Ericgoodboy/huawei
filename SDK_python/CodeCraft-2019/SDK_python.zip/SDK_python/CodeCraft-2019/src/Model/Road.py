import numpy
class Road():
    NOCAR="none"
    TYPE="Road"
    def __init__(self,id,length,speed,channel,fromCrossId,toCrossId,isDuplex):
        self.id=id
        self.length=length
        self.speed=speed
        self.fromCrossId=fromCrossId
        self.channel=channel
        self.toCrossId=toCrossId
        self.isDuplex=isDuplex
        self.arg=0
        if isDuplex:
            self.placesA=numpy.zeros((channel,length),dtype="int32")#from - to
            self.placesB=numpy.zeros((channel,length),dtype="int32")#to - from
        else:
            self.placesA=numpy.zeros((channel,length),dtype="int32")#from - tos
    def maxToGo(self,v,start):#获取最大的可走的距离
        temp=None
        if start=="from":
            temp=self.placesA
        else:
            temp=self.placesB

        for i in range(self.channel):
            if self.placesA[i][0] !=0:
                continue
            else:

                pass
    def runInroad(self,carPool,roadPool,crossPool):
        nowPlace=1
        changeRoad=0
        for channel in self.placesA:
            i=0
            for index in channel:
                if index != 0 and carPool[index].canGoOnRoad and carPool[index].isReadyToGo:
                    car=carPool[index]
                    v=min(car.speed,self.speed)
                    OtherCar=0
                    for k in  channel[i+1:i+v]:
                        if k!=0:
                            OtherCar +=1
                            if carPool[k].isReadyToGo==False:
                                car.isReadyToGo = False
                                changeRoad += 1
                    if OtherCar==0:
                        self.carGo(True,channel,i,i+v,index,carPool,roadPool,crossPool)
                        changeRoad += 1
                i+=1
        return changeRoad
    #车能成功走调用
    def carGo(self,positive,channel,fromIndex,toIndex,carId,carPool,roadPool,crossPool):
        place=self.placesA
        if not positive:
            place=self.placesB
        if fromIndex != -1:
            channel[fromIndex]=0
        channel[toIndex]=carId
        carPool[carId].isReadyToGo=False
        carPool[carId].canGoOnRoad=self.length-toIndex>min(carPool[carId].speed,self.speed)
        if carPool[carId].canGoOnRoad !=True:
            car=carPool[carId]
            indexRoad=car.path.index(self.id)
            if indexRoad==len(car.path)-1:
                car.togoNext=0
            else:
                nextRoad=car.path[indexRoad+1]
                temp=[self.fromCrossId,self.toCrossId]
                cross=roadPool[nextRoad].fromCrossId if roadPool[nextRoad].fromCrossId in temp else roadPool[nextRoad].toCrossId
                f=crossPool[cross].allRoad.index(self.id)
                t=crossPool[cross].allRoad.index(nextRoad)
                direction=(f-t)%4
                print("road"+"carId:", car.id, "f:", f, "t", t,"now:",self.id,"next",nextRoad)
                car.togoNext=direction
                car.lest=self.length-toIndex

    def __str__(self):
        return str(self.fromCrossId)+">"+str(self.toCrossId)