import turtle
import time
turtle.home()
turtle.speed(9)
# 当前画笔大小为1
a=[1,2,3,3]


# turtle.right(100)
# turtle.fd(1000)
# turtle.dot()
# turtle.right(100)



time.sleep(1000)

print(turtle.position())
print(turtle.heading())

