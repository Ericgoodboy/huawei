#!/bin/bash
cd CodeCraft-2019
python3 src/CodeCraft-2019.py 1-map-training-2/car.txt 1-map-training-2/road.txt 1-map-training-2/cross.txt 1-map-training-2/answer.txt
