#!/bin/bash
cd CodeCraft-2019
python3 src/CodeCraft-2019.py 2-map-training-1/car.txt 2-map-training-1/road.txt 2-map-training-1/cross.txt 2-map-training-1/presetAnswer.txt  2-map-training-1/answer.txt
