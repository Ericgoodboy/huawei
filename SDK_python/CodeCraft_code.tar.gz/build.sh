#!/bin/bash
cd CodeCraft-2019
python3 src/CodeCraft-2019.py 1-map-exam-1/car.txt 1-map-exam-1/road.txt 1-map-exam-1/cross.txt 1-map-exam-1/answer2.txt
